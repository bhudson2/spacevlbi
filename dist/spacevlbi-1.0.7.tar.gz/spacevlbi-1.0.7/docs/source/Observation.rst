.. module:: Observation

Observation
===========
.. automodule:: spacevlbi.Observation
    :members:
